import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'path';
import { connectDB } from './database-simple.js';
import ordersRouter from './routes/orders-new.js';

const app = express();
app.use(cors());
app.use(express.json());

// Connect to database
connectDB();

// Serve static files
app.use(express.static('../frontend/dist'));

// API routes
app.use('/api/orders', ordersRouter);

// Serve React app
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api') || req.path.startsWith('/webhooks')) {
    return next();
  }
  res.sendFile(path.join(process.cwd(), '../frontend/dist/index.html'));
});

const PORT = process.env.PORT || 3003;
app.listen(PORT, () => {
  console.log(`✅ Server running on port ${PORT}`);
});